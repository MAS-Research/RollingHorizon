The following files contains the data (requests) used for the experiments. 

- requests_1.csv : the sample containing 1% of requests
- requests_10.csv : the sample containing 10% of requests 
- requests_20.csv : the sample containing 20% of requests